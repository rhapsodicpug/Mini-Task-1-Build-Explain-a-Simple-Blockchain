import React, { useState, useEffect } from "react";
import { Blockchain, Block } from "./utils/Blockchain";
import BlockCard from "./components/BlockCard";
import Controls from "./components/Controls";

function App() {
  const [blockchain, setBlockchain] = useState(new Blockchain(4));
  const [miningInfo, setMiningInfo] = useState(null);
  const [isValid, setIsValid] = useState(true);

  // Initialize chain with 3 blocks on first load
  useEffect(() => {
    const bc = new Blockchain(4);
    bc.addBlock(new Block(1, Date.now(), "Block 1 Data", bc.getLatestBlock().hash));
    bc.addBlock(new Block(2, Date.now(), "Block 2 Data", bc.getLatestBlock().hash));
    setBlockchain(bc);
    setIsValid(bc.isChainValid());
  }, []);

  const handleAddBlock = (data) => {
    const bc = blockchain;
    const newBlock = new Block(bc.chain.length, Date.now(), data, bc.getLatestBlock().hash);
    const mineResult = bc.addBlock(newBlock);
    setMiningInfo(mineResult);
    setBlockchain(Object.assign(Object.create(Object.getPrototypeOf(bc)), bc)); // force update
    setIsValid(bc.isChainValid());
  };

  const handleTamperBlock = (index, newData) => {
    const bc = blockchain;
    const success = bc.tamperBlock(index, newData);
    if (!success) {
      alert("Invalid block index to tamper.");
      return;
    }
    setBlockchain(Object.assign(Object.create(Object.getPrototypeOf(bc)), bc)); // force update
    setIsValid(bc.isChainValid());
    setMiningInfo(null);
  };

  return (
    <div style={{ maxWidth: 800, margin: "auto", padding: 20, fontFamily: "Arial, sans-serif" }}>
      <h1>Blockchain Simulator</h1>

      <Controls onAddBlock={handleAddBlock} onTamperBlock={handleTamperBlock} />

      <div>
        {blockchain.chain.map((block) => (
          <BlockCard key={block.index} block={block} />
        ))}
      </div>

      <div style={{ marginTop: 20 }}>
        <b>Chain Validity:</b>{" "}
        <span style={{ color: isValid ? "green" : "red" }}>
          {isValid ? "Valid ✅" : "Invalid ❌"}
        </span>
      </div>

      {miningInfo && (
        <div style={{ marginTop: 10 }}>
          <b>Mining Info:</b>
          <div>Nonce attempts: {miningInfo.attempts}</div>
          <div>Time taken: {miningInfo.timeTaken.toFixed(3)} seconds</div>
        </div>
      )}

      <footer style={{ marginTop: 40, fontSize: 12, color: "#666" }}>
        Demo Blockchain by Arya Manjardekar
      </footer>
    </div>
  );
}

export default App;

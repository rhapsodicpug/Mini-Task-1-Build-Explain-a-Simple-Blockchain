import React, { useState } from "react";

export default function Controls({ onAddBlock, onTamperBlock }) {
  const [data, setData] = useState("");
  const [tamperIndex, setTamperIndex] = useState("");
  const [tamperData, setTamperData] = useState("");

  const handleAdd = () => {
    if (data.trim() !== "") {
      onAddBlock(data.trim());
      setData("");
    }
  };

  const handleTamper = () => {
    const index = parseInt(tamperIndex, 10);
    if (!isNaN(index) && tamperData.trim() !== "") {
      onTamperBlock(index, tamperData.trim());
      setTamperIndex("");
      setTamperData("");
    }
  };

  return (
    <div style={{marginBottom: 20}}>
      <h3>Add New Block</h3>
      <input
        type="text"
        placeholder="Block data"
        value={data}
        onChange={(e) => setData(e.target.value)}
        style={{padding: 8, width: 200, marginRight: 8}}
      />
      <button onClick={handleAdd}>Add Block</button>

      <h3 style={{marginTop: 30}}>Tamper with a Block</h3>
      <input
        type="number"
        placeholder="Block index (1 or 2)"
        value={tamperIndex}
        onChange={(e) => setTamperIndex(e.target.value)}
        style={{padding: 8, width: 150, marginRight: 8}}
      />
      <input
        type="text"
        placeholder="New data"
        value={tamperData}
        onChange={(e) => setTamperData(e.target.value)}
        style={{padding: 8, width: 200, marginRight: 8}}
      />
      <button onClick={handleTamper}>Tamper Block</button>
    </div>
  );
}

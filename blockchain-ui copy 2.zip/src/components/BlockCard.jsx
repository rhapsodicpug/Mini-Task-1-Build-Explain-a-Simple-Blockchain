import React from "react";

export default function BlockCard({ block }) {
  return (
    <div style={{border: "1px solid #ccc", padding: 12, marginBottom: 12, borderRadius: 8, backgroundColor: "#f9f9f9"}}>
      <div><b>Block #{block.index}</b></div>
      <div>Timestamp: {new Date(block.timestamp).toLocaleString()}</div>
      <div>Data: {typeof block.data === "object" ? JSON.stringify(block.data) : block.data}</div>
      <div>Nonce: {block.nonce}</div>
      <div>Previous Hash: <code>{block.previousHash}</code></div>
      <div>Hash: <code>{block.hash}</code></div>
    </div>
  );
}
